// URL of the backend (Spring Boot). Change the port here if your backend runs on a different one.
const API_BASE = "http://localhost:8080";

// ---------- shared helpers used by every page ----------
function getToken() { return localStorage.getItem("token"); }
function getRole() { return localStorage.getItem("role"); }

function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, c =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function money(n) { return "\u20B9" + Number(n).toFixed(2); }

function logout() {
  localStorage.clear();
  window.location = "index.html";
}

async function api(path, method = "GET", body = null) {
  const headers = { "Content-Type": "application/json" };
  if (getToken()) headers["Authorization"] = "Bearer " + getToken();
  const res = await fetch(API_BASE + path, { method, headers, body: body ? JSON.stringify(body) : null });
  const text = await res.text();
  let data = null;
  if (text) { try { data = JSON.parse(text); } catch (e) { data = text; } }
  if (!res.ok) {
    if (res.status === 401 && getToken() && !path.startsWith("/api/auth")) { logout(); }   // token expired
    throw new Error((data && data.message) || "Request failed (" + res.status + ")");
  }
  return data;
}

// call at top of protected pages: requireLogin("CUSTOMER") or requireLogin("ADMIN")
function requireLogin(role) {
  if (!getToken()) { window.location = "index.html"; return; }
  if (role && getRole() !== role) {
    window.location = getRole() === "ADMIN" ? "admin.html" : "menu.html";
  }
}

function renderNav() {
  const links = getRole() === "ADMIN"
    ? '<a href="admin.html">Admin Dashboard</a>'
    : '<a href="menu.html">Restaurants</a><a href="orders.html">My Orders</a>';
  document.getElementById("nav").innerHTML =
    '<div class="navbar"><span class="brand">\uD83C\uDF54 Food Ordering</span><div>' +
    '<span>Hi, ' + esc(localStorage.getItem("name")) + '</span>' + links +
    '<button onclick="logout()">Logout</button></div></div>';
}

// ---------- star rating helpers ----------
function starsHtml(avg) {
  const full = Math.round(avg);
  return '<span class="stars">' + '\u2605'.repeat(full) + '\u2606'.repeat(5 - full) + '</span>';
}
function ratingLine(r) {
  return r.ratingCount > 0
    ? starsHtml(r.avgRating) + ' <b>' + Number(r.avgRating).toFixed(1) + '</b> <span style="color:#777">(' + r.ratingCount + ' rating' + (r.ratingCount > 1 ? 's' : '') + ')</span>'
    : '<span style="color:#777">No ratings yet</span>';
}
